window.__dayDataCallback__([
  {
  "name": "აგვისტო - 24",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+აგვისტო+nature"
}
]);