window.__dayDataCallback__([
  {
  "name": "ქართული ფოლკლორის საღამო",
  "fact": "ზაფხულის თვეებში, განსაკუთრებით ივლისში, თბილისსა და ბათუმში ხშირად იმართება ქართული ფოლკლორის საღამოები, სადაც ანსამბლები მრავალხმიან სიმღერებსა და ცეკვებს ასრულებენ.",
  "img": "https://unsplash.com/s?query=georgian+folk+dance+polyphonic+singing+concert"
}
]);