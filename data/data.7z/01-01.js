window.__dayDataCallback__([
  {
  "name": "ახალი წელი",
  "fact": "საქართველოში ახალ წელს ტრადიციულად ხვდებიან ჩხირთმელას (საშობაო მორის) ანთებით და მდიდრული სუფრით, რომელიც მთელი ღამე გრძელდება.",
  "img": "https://unsplash.com/s?query=georgian+new+year+table+traditional"
}
]);