window.__dayDataCallback__([
  {
  "name": "ნინოობა (წმინდა ნინოს შემოსვლის დღე)",
  "fact": "წმინდა ნინოს, საქართველოს განმანათლებლის, ქვეყანაში შემოსვლის დღე. მისი ქადაგებით IV საუკუნეში ქრისტიანობა სახელმწიფო რელიგიად გამოცხადდა [citation:2].",
  "img": "https://unsplash.com/s?query=st+nino+georgia+cross+grapevine"
}
]);