window.__dayDataCallback__([
  {
  "name": "ივლისი - 10",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+ივლისი+nature"
}
]);