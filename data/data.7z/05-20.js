window.__dayDataCallback__([
  {
  "name": "მაისი - 20",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);