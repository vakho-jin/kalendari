window.__dayDataCallback__([
  {
  "name": "თებერვალი - 29",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);