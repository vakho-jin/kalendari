window.__dayDataCallback__([
  {
  "name": "ნოვრუზი (აზერბაიჯანული დღესასწაული)",
  "fact": "გაზაფხულის დადგომის და მზის ახალი წლის დღესასწაული. საქართველოში მცხოვრები აზერბაიჯანული თემი (მოსახლეობის დაახლოებით 6%) მას განსაკუთრებულად ზეიმობს [citation:2].",
  "img": "https://unsplash.com/s?query=novruz+holiday+spring+celebration"
}
]);