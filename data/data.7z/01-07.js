window.__dayDataCallback__([
  {
  "name": "შობა",
  "fact": "მართლმადიდებლური შობა საქართველოში. ტაძრებში ღამისთევის წირვა-ლოცვა აღევლინება, ხოლო 7 იანვარს ოჯახები სადღესასწაულო ტრაპეზზე იკრიბებიან [citation:2][citation:3][citation:5].",
  "img": "https://unsplash.com/s?query=orthodox+christmas+georgia+tbilisi"
}
]);