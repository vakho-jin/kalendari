window.__dayDataCallback__([
  {
  "name": "რთველი (დაწყება)",
  "fact": "ყურძნის კრეფის ტრადიციული დღესასწაული კახეთში. მთელი ოჯახი და მეზობლები ვენახებში იკრიბებიან, მღერიან, ჭაჭას ახალ ღვინოს ასხამენ და ტრადიციულ კერძებს მიირთმევენ [citation:2][citation:5].",
  "img": "https://unsplash.com/s?query=rtveli+grape+harvest+kakheti+georgia"
}
]);