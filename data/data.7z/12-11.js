window.__dayDataCallback__([
  {
  "name": "დეკემბერი - 11",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+დეკემბერი+nature"
}
]);