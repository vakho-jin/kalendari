window.__dayDataCallback__([
  {
  "name": "წინანდლის ფესტივალი",
  "fact": "ყოველწლიური საერთაშორისო კლასიკური მუსიკის ფესტივალი წინანდალში, ჭავჭავაძეების ისტორიულ მამულში. აერთიანებს სიმფონიურ ორკესტრებს, კამერულ ანსამბლებსა და ოპერის სოლისტებს [citation:5].",
  "img": "https://unsplash.com/s?query=tsinandali+festival+classical+music+estate"
}
]);