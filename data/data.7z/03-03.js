window.__dayDataCallback__([
  {
  "name": "დედის დღე",
  "fact": "დედის დღე საქართველოში 1991 წელს პირველმა პრეზიდენტმა, ზვიად გამსახურდიამ, დააწესა. ამ დღეს დედებს ყვავილებით და საჩუქრებით ულოცავენ [citation:2].",
  "img": "https://unsplash.com/s?query=mothers+day+flowers+georgia"
}
]);