window.__dayDataCallback__([
  {
  "name": "ხალხური ხელოსნობის დღე",
  "fact": "ოქტომრის ბოლოს თბილისში ხშირად იმართება ხალხური ხელოსნობის დღე, სადაც მეთუნეები, მჭედლები და მხატვრები თავიანთ ნახელავს გამოფენენ.",
  "img": "https://unsplash.com/s?query=georgian+crafts+pottery+metalwork+fair"
}
]);