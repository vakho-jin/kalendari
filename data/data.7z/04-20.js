window.__dayDataCallback__([
  {
  "name": "აპრილი - 20",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+აპრილი+nature"
}
]);