window.__dayDataCallback__([
  {
  "name": "დეკემბერი - 16",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+დეკემბერი+nature"
}
]);