window.__dayDataCallback__([
  {
  "name": "სიყვარულის დღე",
  "fact": "შედარებით ახალი დღესასწაული, რომელიც წმინდა ვალენტინის დღის ალტერნატივად იქცა. ამ დღეს შეყვარებულები ერთმანეთს განსაკუთრებულ ყურადღებას აქცევენ [citation:2].",
  "img": "https://unsplash.com/s?query=love+day+georgia+romantic+date"
}
]);