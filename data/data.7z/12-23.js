window.__dayDataCallback__([
  {
  "name": "დეკემბერი - 23",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+დეკემბერი+nature"
}
]);