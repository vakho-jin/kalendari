window.__dayDataCallback__([
  {
  "name": "ოქტომბერი - 30",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+ოქტომბერი+nature"
}
]);