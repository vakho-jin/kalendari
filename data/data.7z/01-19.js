window.__dayDataCallback__([
  {
  "name": "ნათლისღება",
  "fact": "იესო ქრისტეს ნათლისღების დღესასწაული. მღვდელმსახურები აკურთხებენ წყალს მდინარეებსა და ტბებში. მორწმუნეები ჯვრის სახით ამოჭრილ ყინულში („იორდანე“) ბანაობენ [citation:2][citation:5].",
  "img": "https://unsplash.com/s?query=epiphany+georgia+blessing+water+river"
}
]);