window.__dayDataCallback__([
  {
  "name": "ახალი წლის ღამე",
  "fact": "საქართველოში ახალ წელს ტრადიციულად მდიდრულ სუფრასთან, ოჯახის წევრებთან ერთად ხვდებიან. სუფრაზე აუცილებლად უნდა იყოს საჩენისი (გოჭი), საცივი, გოზინაყი და ჩურჩხელა. შუაღამისას თბილისის ცას ფეიერვერკები გაანათებს [citation:5][citation:8].",
  "img": "https://unsplash.com/s?query=georgian+new+year+eve+table+family+fireworks"
}
]);