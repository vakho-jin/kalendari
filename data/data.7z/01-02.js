window.__dayDataCallback__([
  {
  "name": "ბედობა",
  "fact": "მეორე იანვარს საქართველოში 'ბედობას' აღნიშნავენ. ითვლება, როგორც დღეს გაატარებ, ისეთივე გექნება მთელი წელი. დღეს ოჯახში, მშვიდობითა და სიყვარულით ატარებენ [citation:2].",
  "img": "https://unsplash.com/s?query=georgian+family+supper+new+year"
}
]);