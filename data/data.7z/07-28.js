window.__dayDataCallback__([
  {
  "name": "კვირიკობა",
  "fact": "წმინდა მოწამეების, კვირიკესა და ივლიტას ხსენების დღე. განსაკუთრებულად აღინიშნება სვანეთში, ლამისკანასა და სხვა სოფლებში. დღესასწაულის ნაწილია ქართული ჭიდაობა [citation:2].",
  "img": "https://unsplash.com/s?query=kvirkoba+svaneti+georgian+wrestling"
}
]);