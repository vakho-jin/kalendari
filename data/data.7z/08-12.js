window.__dayDataCallback__([
  {
  "name": "აგვისტო - 12",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+აგვისტო+nature"
}
]);