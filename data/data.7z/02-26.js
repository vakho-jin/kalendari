window.__dayDataCallback__([
  {
  "name": "თებერვალი - 26",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);