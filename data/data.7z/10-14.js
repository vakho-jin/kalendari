window.__dayDataCallback__([
  {
  "name": "მცხეთობა (სვეტიცხოვლობა)",
  "fact": "უფლის კვართის დღესასწაული მცხეთაში. გადმოცემით, სვეტიცხოვლის საკათედრო ტაძარში დაკრძალულია ქრისტეს სამოსელი. ეს დღე საქართველოს ერთ-ერთი უდიდესი რელიგიური დღესასწაულია [citation:2][citation:7].",
  "img": "https://unsplash.com/s?query=svetitskhoveli+cathedral+mtskheta+feast"
}
]);