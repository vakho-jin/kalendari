window.__dayDataCallback__([
  {
  "name": "თებერვალი - 22",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);