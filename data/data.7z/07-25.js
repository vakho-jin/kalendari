window.__dayDataCallback__([
  {
  "name": "თბილისი ოუფენ ეარი",
  "fact": "საქართველოს ყველაზე მასშტაბური მუსიკალური ფესტივალი, სადაც როკი, ელექტრონული მუსიკა და მსოფლიო ჰიტები ჟღერს. ფესტივალი ათასობით სტუმარს იზიდავს [citation:5].",
  "img": "https://unsplash.com/s?query=tbilisi+open+air+festival+crowd+music"
}
]);