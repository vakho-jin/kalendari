window.__dayDataCallback__([
  {
  "name": "იანვარი - 03",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს სინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+იანვარი+nature"
}
]);