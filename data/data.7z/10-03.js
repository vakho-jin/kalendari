window.__dayDataCallback__([
  {
  "name": "ოქტომბერი - 03",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+ოქტომბერი+nature"
}
]);