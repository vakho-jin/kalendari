window.__dayDataCallback__([
  {
  "name": "გიორგობა",
  "fact": "წმინდა გიორგის, საქართველოს ზეციური მფარველის, დღესასწაული. ეს ქვეყნის ერთ-ერთი ყველაზე პატივცემული დღეა. ტაძრებში საზეიმო წირვა აღევლინება [citation:2][citation:7].",
  "img": "https://unsplash.com/s?query=giorgoba+st+george+georgia+feast"
}
]);