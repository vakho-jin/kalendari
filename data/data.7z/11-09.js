window.__dayDataCallback__([
  {
  "name": "ნოემბერი - 09",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+ნოემბერი+nature"
}
]);