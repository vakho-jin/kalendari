window.__dayDataCallback__([
  {
  "name": "კონსტანტინე გამსახურდიას დაბადების დღე",
  "fact": "XX საუკუნის გამოჩენილი ქართველი მწერლის, კონსტანტინე გამსახურდიას (პირველი პრეზიდენტის მამის) დაბადების დღე. აქტიურად აღინიშნება მის მშობლიურ ქალაქ აბაშაში [citation:2].",
  "img": "https://unsplash.com/s?query=georgian+writer+konstantine+gamsakhurdia+memorial"
}
]);