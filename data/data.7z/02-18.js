window.__dayDataCallback__([
  {
  "name": "თებერვალი - 18",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);