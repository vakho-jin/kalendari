window.__dayDataCallback__([
  {
  "name": "მარიამობა",
  "fact": "ღვთისმშობლის მიძინების დღესასწაული. იწყება ღამისთევის წირვით. მარიამობას ყველა ეკლესიაში საზეიმო წირვა აღევლინება [citation:2].",
  "img": "https://unsplash.com/s?query=mariamoba+dormition+georgia+church"
}
]);