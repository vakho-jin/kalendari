window.__dayDataCallback__([
  {
  "name": "გერგეთობა",
  "fact": "სულიერი სიყვარულის დღესასწაული, აღდგენილი სრულიად საქართველოს კათოლიკოს-პატრიარქის, ილია II-ის ინიციატივით [citation:2].",
  "img": "https://unsplash.com/s?query=gergetoba+georgia+spiritual+love"
}
]);