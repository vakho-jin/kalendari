window.__dayDataCallback__([
  {
  "name": "ნოემბერი - 19",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+ნოემბერი+nature"
}
]);