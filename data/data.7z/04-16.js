window.__dayDataCallback__([
  {
  "name": "წაჩხურობა",
  "fact": "აღდგომის შემდგომი ხუთშაბათი, ცნობილი მარტვილის რაიონის სოფელ წაჩხურში აკვნების ანთების ტრადიციით. უშვილო წყვილები შვილის ბოძების სათხოვნელად მოდიან [citation:2].",
  "img": "https://unsplash.com/s?query=tsachkhuroba+martvili+candle+tradition"
}
]);