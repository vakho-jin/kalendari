window.__dayDataCallback__([
  {
  "name": "მაისი - 21",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);