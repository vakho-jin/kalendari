window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 18",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);