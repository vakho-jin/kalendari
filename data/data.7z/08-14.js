window.__dayDataCallback__([
  {
  "name": "აგვისტო - 14",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+აგვისტო+nature"
}
]);