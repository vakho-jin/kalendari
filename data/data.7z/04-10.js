window.__dayDataCallback__([
  {
  "name": "წითელი პარასკევი",
  "fact": "ვნების კვირის პარასკევი, იესო ქრისტეს ჯვარცმის ხსენების დღე. მორწმუნეები მკაცრ მარხვას იცავენ, ეკლესიებში კი წირვის დროს გამოჰყავთ წმინდა სამსჭვალი [citation:2].",
  "img": "https://unsplash.com/s?query=good+friday+orthodox+church+candle"
}
]);