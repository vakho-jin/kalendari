window.__dayDataCallback__([
  {
  "name": "აპრილი - 08",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+აპრილი+nature"
}
]);