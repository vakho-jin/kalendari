window.__dayDataCallback__([
  {
  "name": "ნოემბერი - 07",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+ნოემბერი+nature"
}
]);