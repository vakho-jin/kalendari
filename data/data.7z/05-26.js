window.__dayDataCallback__([
  {
  "name": "დამოუკიდებლობის დღე",
  "fact": "1918 წელს პირველი დემოკრატიული რესპუბლიკის გამოცხადების დღე. აღინიშნება სამხედრო აღლუმით, კონცერტებითა და სახალხო დღესასწაულებით [citation:2][citation:5].",
  "img": "https://unsplash.com/s?query=georgia+independence+day+parade+tbilisi+flag"
}
]);