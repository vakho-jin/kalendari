window.__dayDataCallback__([
  {
  "name": "მარტი - 19",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+მარტი+nature"
}
]);