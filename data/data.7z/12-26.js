window.__dayDataCallback__([
  {
  "name": "დეკემბერი - 26",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+დეკემბერი+nature"
}
]);