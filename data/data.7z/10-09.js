window.__dayDataCallback__([
  {
  "name": "ოქტომბერი - 09",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+ოქტომბერი+nature"
}
]);