window.__dayDataCallback__([
  {
  "name": "ქალთა საერთაშორისო დღე",
  "fact": "8 მარტი საქართველოში 1996 წლიდან აღინიშნება, როგორც ქალთა უფლებებისა და გაზაფხულის დღე. ქუჩები მიმოზათი და ყვავილებით იფარება [citation:2].",
  "img": "https://unsplash.com/s?query=international+womens+day+mimosa+flowers"
}
]);