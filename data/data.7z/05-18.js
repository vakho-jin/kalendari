window.__dayDataCallback__([
  {
  "name": "მაისი - 18",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);