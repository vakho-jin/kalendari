window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 24",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);