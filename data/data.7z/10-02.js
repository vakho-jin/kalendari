window.__dayDataCallback__([
  {
  "name": "თბილისობა",
  "fact": "თბილისის დღესასწაული. ძველი თბილისის ქუჩებში იმართება კონცერტები, ხელოსნების გამოფენა-გაყიდვები, გასტრონომიული ფესტივალები. ეს არის ქალაქის ისტორიის, კულტურისა და მრავალფეროვნების ზეიმი [citation:2][citation:5].",
  "img": "https://unsplash.com/s?query=tbilisoba+festival+old+tbilisi+street+fair"
}
]);