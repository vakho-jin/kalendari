window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 20",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);