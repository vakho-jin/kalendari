window.__dayDataCallback__([
  {
  "name": "ფაშიზმზე გამარჯვების დღე",
  "fact": "მეორე მსოფლიო ომში გამარჯვების დღე. საქართველოში 700 000-მდე მებრძოლი მონაწილეობდა, აქედან 400 000 დაიღუპა [citation:2].",
  "img": "https://unsplash.com/s?query=victory+day+georgia+ww2+memorial"
}
]);