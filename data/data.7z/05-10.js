window.__dayDataCallback__([
  {
  "name": "მაისი - 10",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);