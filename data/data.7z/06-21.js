window.__dayDataCallback__([
  {
  "name": "ივნისი - 21",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+ივნისი+nature"
}
]);