window.__dayDataCallback__([
  {
  "name": "მაისი - 07",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);