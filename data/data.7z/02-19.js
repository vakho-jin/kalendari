window.__dayDataCallback__([
  {
  "name": "თებერვალი - 19",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);