window.__dayDataCallback__([
  {
  "name": "ქართული ღვინის დღე",
  "fact": "იანვრის ბოლოს ხშირად იმართება ქართული ღვინისადმი მიძღვნილი ღონისძიებები, სადაც წარმოდგენილია როგორც ცნობილი, ისე მცირე მეღვინეობის ნიმუშები.",
  "img": "https://unsplash.com/s?query=georgian+wine+qvevri+traditional"
}
]);