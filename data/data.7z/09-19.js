window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 19",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);