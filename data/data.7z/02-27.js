window.__dayDataCallback__([
  {
  "name": "თებერვალი - 27",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+თებერვალი+nature"
}
]);