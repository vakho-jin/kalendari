window.__dayDataCallback__([
  {
  "name": "აპრილი - 04",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+აპრილი+nature"
}
]);