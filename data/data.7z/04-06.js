window.__dayDataCallback__([
  {
  "name": "აპრილი - 06",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+აპრილი+nature"
}
]);