window.__dayDataCallback__([
  {
  "name": "ლამპრობა",
  "fact": "სვანური უძველესი დღესასწაული წმინდა გიორგის პატივსაცემად. ღამით ანთებენ ჩირაღდნებსა და კოცონებს, მღერიან სვანურ სიმღერებს. ეს სიმბოლურად გამარჯვებისა და გაზაფხულის დაწყების მაუწყებელია [citation:2][citation:5].",
  "img": "https://unsplash.com/s?query=lamproba+svaneti+torch+festival+fire"
}
]);