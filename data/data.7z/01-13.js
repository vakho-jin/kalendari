window.__dayDataCallback__([
  {
  "name": "ძველი ახალი წელი",
  "fact": "ძველი ახალი წელი (14 იანვრის ღამე) საქართველოში იულიუსის კალენდრის მიხედვით აღინიშნება. ეს კიდევ ერთი საშუალებაა ოჯახთან ერთად, მშვიდ გარემოში, სუფრასთან შეკრებისთვის [citation:5].",
  "img": "https://unsplash.com/s?query=old+new+year+celebration+family"
}
]);