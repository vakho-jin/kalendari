window.__dayDataCallback__([
  {
  "name": "ოქტომბერი - 15",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+ოქტომბერი+nature"
}
]);