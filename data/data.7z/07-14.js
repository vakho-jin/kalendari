window.__dayDataCallback__([
  {
  "name": "ივლისი - 14",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+ივლისი+nature"
}
]);