window.__dayDataCallback__([
  {
  "name": "იანვარი - 28",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+იანვარი+nature"
}
]);