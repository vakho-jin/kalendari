window.__dayDataCallback__([
  {
  "name": "ნოემბერი - 26",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+ნოემბერი+nature"
}
]);