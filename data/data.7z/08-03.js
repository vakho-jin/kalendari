window.__dayDataCallback__([
  {
  "name": "აგვისტო - 03",
  "fact": "საქართველოს მთიან რეგიონებში ამ დროს განსაკუთრებული ბუნებაა.",
  "img": "https://unsplash.com/s?query=georgia+აგვისტო+nature"
}
]);