window.__dayDataCallback__([
  {
  "name": "თბილისის ჯაზ-ფესტივალი",
  "fact": "თბილისის ჯაზ-ფესტივალი ნოემბერში იმართება. თანამედროვე ჯაზი კლასიკურს ხვდება და მუსიკის მოყვარულთათვის დაუვიწყარ კონცერტებს ქმნის [citation:5].",
  "img": "https://unsplash.com/s?query=tbilisi+jazz+festival+concert+piano"
}
]);