window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 22",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);