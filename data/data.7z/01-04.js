window.__dayDataCallback__([
  {
  "name": "იანვარი - 04",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+იანვარი+nature"
}
]);