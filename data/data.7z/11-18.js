window.__dayDataCallback__([
  {
  "name": "ნოემბერი - 18",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+ნოემბერი+nature"
}
]);