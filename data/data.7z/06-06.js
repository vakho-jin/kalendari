window.__dayDataCallback__([
  {
  "name": "ივნისი - 06",
  "fact": "თბილისის ძველ უბნებში ტრადიციული ცხოვრების რიტმი გრძელდება.",
  "img": "https://unsplash.com/s?query=georgia+ივნისი+nature"
}
]);