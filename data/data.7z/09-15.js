window.__dayDataCallback__([
  {
  "name": "ცოდნის დღე",
  "fact": "საქართველოში სასწავლო წელი 15 სექტემბერს იწყება. სკოლებში პირველკლასელებისთვის საზეიმო ხაზი იმართება [citation:2].",
  "img": "https://unsplash.com/s?query=school+georgia+first+bell+children"
}
]);