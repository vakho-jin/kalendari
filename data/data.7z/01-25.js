window.__dayDataCallback__([
  {
  "name": "იანვარი - 25",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+იანვარი+nature"
}
]);