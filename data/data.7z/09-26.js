window.__dayDataCallback__([
  {
  "name": "სექტემბერი - 26",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+სექტემბერი+nature"
}
]);