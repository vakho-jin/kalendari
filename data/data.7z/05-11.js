window.__dayDataCallback__([
  {
  "name": "მაისი - 11",
  "fact": "ქართული მრავალხმიანობის დღე - ამ დღეს ხალხური სიმღერები ისმის.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);