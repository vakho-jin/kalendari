window.__dayDataCallback__([
  {
  "name": "აპრილი - 25",
  "fact": "ამ დღეს ქართველი მეღვინეები ახალ ღვინოს ასინჯავენ.",
  "img": "https://unsplash.com/s?query=georgia+აპრილი+nature"
}
]);