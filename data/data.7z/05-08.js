window.__dayDataCallback__([
  {
  "name": "მაისი - 08",
  "fact": "ქართული სუფრის ტრადიცია მრავალსაუკუნოვანი ისტორიით გამოირჩევა.",
  "img": "https://unsplash.com/s?query=georgia+მაისი+nature"
}
]);