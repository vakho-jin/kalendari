window.__dayDataCallback__([
  {
  "name": "ოჯახის სიწმინდისა და მშობლების პატივისცემის დღე",
  "fact": "დღესასწაული, რომელიც პირველად 2025 წელს აღინიშნა, ხაზს უსვამს ტრადიციული ოჯახური ღირებულებების პატივისცემას [citation:2].",
  "img": "https://unsplash.com/s?query=georgian+family+traditional+values"
}
]);