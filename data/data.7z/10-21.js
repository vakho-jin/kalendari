window.__dayDataCallback__([
  {
  "name": "ოქტომბერი - 21",
  "fact": "საქართველოში ამ დღეს ტრადიციულად ოჯახურ სადილზე იკრიბებიან.",
  "img": "https://unsplash.com/s?query=georgia+ოქტომბერი+nature"
}
]);